<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		},
		globalData:{
			siteurl:'https://smile.meishaogirl.top/phalapi/public/?s='
		}
	}
</script>

<style>
	/*每个页面公共css */
</style>
