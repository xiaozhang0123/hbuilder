<template>
	<view class="content">
		<image class="logo" src="/static/logo.png"></image>
		<view class="text-area">
			<text class="title">{{title}}</text>
		</view>
		<view class="text-area">
			<text>我是{{user_nickname}}</text>
		</view>
		<view class="text-area">
			<text @click="sharewx">分享给微信好友</text>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			
			return {
				title: '欢迎欢迎，热烈欢迎',
				user_nickname:""
			}
		},
		onLoad:function(option) {
			console.log("欢迎登录");
			this.user_nickname = option.user_nickname;
			
		},
		methods: {
			sharewx: function(){
				uni.share({
					provider: "weixin",
					scene: "WXSceneSession",
					type: 1,
					summary: "我正在使用HBuilderX开发uni-app，赶紧跟我一起来体验！",
					success: function (res) {
						console.log("success:" + JSON.stringify(res));
					},
					fail: function (err) {
						console.log("fail:" + JSON.stringify(err));
					}
				});

			}
		}
	}
</script>

<style>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: center;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}
</style>
