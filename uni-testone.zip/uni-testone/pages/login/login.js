
export default {
	requestpromise
}

/* var requestUrl=getApp().globalData.siteurl;//接口地址
var methodName="Login.userLogin";
var data={
	user_login: '18660860002',
	user_pass: "qq123456",
}; */
export const requestpromise= (url,data) => {
	return new Promise((resolve, reject) => {
		const requestTask = uni.request({
			url: url, 
			data: data,
			success: function(res) {
				var data=res.data.data;
				//服务器返回数据
				if (data.code == 0) {
					resolve(res);
				} else {
					//返回错误提示信息
					reject(res.data);
				}
				console.log(res.data);
			}
		});
	})
	
}

