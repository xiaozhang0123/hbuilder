<template>
	<div>
		<view v-if="!success" >
		  <view class='row code-view'>
				<view class='info'>
					   <input  class= 'info-input' v-model="phone" placeholder="请输入您的手机号" />
				 </view>
				  
		  </view>
		  <view class='row bottom-view'>
				<view class='info'>
					   <input type='password' class= 'info-input' v-model="password" placeholder="请填写密码" />
				 </view>
		 </view>
		
		  <view class='info'>
			<button class='click_button' bindtap='doForgetpwd'>忘记密码</button>
			<button class='click_button' bindtap='doReg' >注册账号</button>
		  </view>
		  <button class='submit' v-on:click='submit'>登录</button>
		 </view>
		 <view v-else> 登录成功，跳转中... </view>
	</div>
</template>

<script>
	import {
		requestpromise
	} from './login.js'
	
	export default {
		data() {
			return {
				userInfo: {},
				hasUserInfo: false,
				phone: '', //获取到的手机栏中的值
				password: '',//登录密码
				success: false,
				user_nickname:'',
			}
		},
		onLoad() {
	
		},
		onReady() {
			
		},
		methods: {
			submit: function (e) {
			    if (this.phone == '') {
			      wx.showToast({
			        title: '请输入手机号码',
			        icon: 'none',
			        duration: 2000
			      })
			      return
			    }
			    if (this.password == '') {
			      wx.showToast({
			        title: '请输入密码',
			        icon: 'none',
			        duration: 2000
			      })
			      return
			    } else {
					var methodName="Login.userLogin";
					var data={
						user_login: this.phone,
						user_pass: this.password,
					};
				    var requestUrl=getApp().globalData.siteurl;//接口地址
				    var loginurl=requestUrl+methodName;
				    requestpromise(loginurl ,data).then(res => {
						console.log("==========="+res.data);
						var user_nickname= res.data.data.info[0]['user_nickname'];
						if(user_nickname){
							uni.switchTab({
								url: '/pages/index/index?user_nickname='+user_nickname
							});
						}
						console.log("user_nickname========"+user_nickname);
					});
					 
				 /* const requestTask = uni.request({
				  	url: requestUrl+methodName, 
				  	data: {
				          user_login: this.phone,
				          user_pass: this.password,
				  	},
				  	success: function(res) {
						var data=res.data;
						var user_nickname= res.data.data.info[0]['user_nickname'];
						uni.redirectTo({
							url: '/pages/index/index?user_nickname='+user_nickname
						});
						console.log(res.data);
				  	}
				  });
			 */
			    }
			},
			
			
			
			
		}
	}
</script>

<style>
	body{
		background-color: #FFFFFF;
	}
	.userinfo {
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	}
	
	.userinfo-avatar {
	  width: 128rpx;
	  height: 128rpx;
	  margin: 20rpx;
	  border-radius: 50%;
	}
	
	.userinfo-nickname {
	  color: #777;
	  font-size: 12px;
	  margin-top: 10px;
	}
	
	.usermotto {
	  margin-top: 200px;
	}
	
	page{
	  background: #F0F0F0 ;
	}
	.row{
	  padding-top: 10px;
	  overflow: hidden;
	  line-height: 120rpx;
	  border-top: 0.5px solid #f6f6f6;
	  color: #777;
	  background: #fff;
	}
	.info-input{
	 height: 120rpx;
	 margin-left: 50rpx;
	 color: #777;
	   float: left;
	}
	
	.button{
	 width: 230rpx;
	 height: 70rpx;
	 line-height: 70rpx;
	 font-size: 26rpx;
	 margin-right: 10rpx;
	 margin-top: 25rpx;
	 background:transparent;	/*按钮背景透明*/
	 border-width:0px;	/*边框透明*/
	 outline:none;	/*点击后没边框*/
	}
	.button::after {
	  border: none;
	}
	.submit{
	 margin-top: 20rpx;
	 margin-left: 5%;
	 margin-right: 5%;
	 /**background: linear-gradient(270deg, rgb(250, 172, 126), rgb(251, 151, 119));*/
	 color: #FFFFFF;
	 border-radius: 30px;
	 width: 88%;
	 background-color: #f64d36;
	
	}
	.success{
	 background: #ffffff;
	
	}
	.cheer{
	 text-align: center;
	 line-height: 400rpx;
	 font-size: 60rpx;
	 position: relative;
	}
	.return{
	 margin: 20rpx;
	
	}
	.texttip{
	  color: #777;
	  font-size: 26rpx;
	  text-align:center;
	  margin: 0 8%;
	}
	.bottom-view{
	  margin-bottom: 10px;
	}
	.phone-png{
	  width: 45rpx;
	  height: 45rpx;
	  line-height: 45rpx;
	  margin-left: 25px;
	  margin-top: 37rpx;
	  display:block;
	}
	.info{
	  display: flex;
	
	}
	.code-view{
	  display: flex;
	}
	.wxlogin::after {
	  border: none;
	}
	.order-login-line {
	  display: block;
	  position: relative;
	  text-align: center;
	  font-size: 14px;
	  color: #777;
	  margin-bottom: 25px
	}
	
	.click_button{
	  width: 230rpx;
	  height: 50rpx;
	  line-height: 50rpx;
	  font-size: 26rpx;
	  background:transparent;	/*按钮背景透明*/
	  border-width:0px;	/*边框透明*/
	  outline:none;	/*点击后没边框*/
	  color: #4D4D4D;
	 }
	 .click_button::after {
	   border: none;
	 }
</style>